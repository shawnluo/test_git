from distutils.core import setup

setup(
    name = 'mfg',
    version = '1.0.0',
    py_modules = ['mfg'],
    author = 'shawn.luo',
    author_email = 'shawn.luo@xx.com',
    url = 'http://xx.com',
    description = 'mfg test tool',
)